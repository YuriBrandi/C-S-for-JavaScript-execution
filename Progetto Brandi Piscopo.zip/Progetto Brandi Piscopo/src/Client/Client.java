/*
    © Brandi Yuri & Piscopo Roberto.
*/
package Client;

import java.net.* ;
import java.io.* ;

// JAR Simple Json: http://www.java2s.com/Code/Jar/j/Downloadjsonsimple111jar.htm
import org.json.simple.* ;
import org.json.simple.parser.* ;

//Classe necessaria per l'implementazione del JFrame.setIconImage(...).
import java.awt.Toolkit;

/*
    Classe necessaria per la modifica del "caret", ovvero del
    cursore della barra di scorrimento della TextArea.
    In questo caso serve per abilitare lo scroll automatico
    quando viene stampato del testo nuovo nel Log.
*/
import javax.swing.text.DefaultCaret;


public class Client extends javax.swing.JFrame{

    //Tutti gli attributi vengono gestidi mediante appositi metodi get/set.
    private String indirizzo, key;
    private int porta;
   
    public Client() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Finestra = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        Titolo2_Lbl = new javax.swing.JLabel();
        info_Lbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Risultato_TA = new javax.swing.JTextArea();
        Inserimento_Lbl = new javax.swing.JLabel();
        Risultato_Lbl = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Inserimento_TA = new javax.swing.JTextArea();
        Esegui_Btn = new javax.swing.JButton();
        jScrollPane = new javax.swing.JScrollPane();
        Log_TA = new javax.swing.JTextArea();
        Log_Lbl = new javax.swing.JLabel();
        Clear_Btn = new javax.swing.JButton();
        chiave_ico = new javax.swing.JLabel();
        jOptionPane = new javax.swing.JOptionPane();
        jPanel = new javax.swing.JPanel();
        Start_Btn = new javax.swing.JButton();
        Titolo_Lbl = new javax.swing.JLabel();
        Porta_Lbl = new javax.swing.JLabel();
        InfoPorta_Lbl = new javax.swing.JLabel();
        Chiave_Lbl = new javax.swing.JLabel();
        Indirizzo_Lbl = new javax.swing.JLabel();
        Indirizzo_Tbx = new javax.swing.JTextField();
        Porta_Tbx = new javax.swing.JFormattedTextField();
        Chiave_Tbx = new javax.swing.JPasswordField();

        Finestra.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        Finestra.setTitle("Compilatore JavaScript");
        Finestra.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icona_client.png")));
        Finestra.setLocation(new java.awt.Point(500, 500));
        Finestra.setPreferredSize(new java.awt.Dimension(720, 600));
        Finestra.setSize(new java.awt.Dimension(720, 600));
        Finestra.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                FinestraWindowClosed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(720, 550));

        Titolo2_Lbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Titolo2_Lbl.setText("Compilatore JavaScript");
        Titolo2_Lbl.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        info_Lbl.setText("Indirizzo: porta");

        Risultato_TA.setEditable(false);
        Risultato_TA.setColumns(20);
        Risultato_TA.setRows(5);
        Risultato_TA.setText("Qui verrà stampato il risultato dell'esecuzione.");
        Risultato_TA.setToolTipText("");
        jScrollPane1.setViewportView(Risultato_TA);

        Inserimento_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Inserimento_Lbl.setText("Inserisci codice JavaScript");

        Risultato_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Risultato_Lbl.setText("Risultato");

        Inserimento_TA.setColumns(20);
        Inserimento_TA.setRows(5);
        Inserimento_TA.setToolTipText("Qui avviene l'input del codice sorgente");
        jScrollPane2.setViewportView(Inserimento_TA);

        Esegui_Btn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Esegui_Btn.setText("Esegui");
        Esegui_Btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Esegui_BtnMouseClicked(evt);
            }
        });

        jScrollPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        Log_TA.setEditable(false);
        Log_TA.setBackground(new java.awt.Color(0, 0, 0));
        Log_TA.setColumns(20);
        Log_TA.setForeground(new java.awt.Color(255, 255, 255));
        Log_TA.setRows(5);
        Log_TA.setText("~~~~~~~~ © Brandi & Piscopo ~~~~~~~~");
        Log_TA.setSelectionColor(new java.awt.Color(255, 0, 204));
        jScrollPane.setViewportView(Log_TA);

        Log_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Log_Lbl.setText("Log");

        Clear_Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Client/baseline_delete_black_18dp.png"))); // NOI18N
        Clear_Btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Clear_BtnMouseClicked(evt);
            }
        });

        chiave_ico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Client/baseline_vpn_key_black_18dp.png"))); // NOI18N
        chiave_ico.setDisabledIcon(null);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Titolo2_Lbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addComponent(jScrollPane2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Inserimento_Lbl)
                                    .addComponent(Risultato_Lbl))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(Esegui_Btn)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 357, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(info_Lbl, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(chiave_ico, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Log_Lbl)
                        .addGap(18, 18, 18)
                        .addComponent(Clear_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Titolo2_Lbl)
                .addGap(56, 56, 56)
                .addComponent(Inserimento_Lbl)
                .addGap(1, 1, 1)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(Esegui_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(Risultato_Lbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(Log_Lbl))
                    .addComponent(Clear_Btn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(chiave_ico)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(info_Lbl))))
        );

        javax.swing.GroupLayout FinestraLayout = new javax.swing.GroupLayout(Finestra.getContentPane());
        Finestra.getContentPane().setLayout(FinestraLayout);
        FinestraLayout.setHorizontalGroup(
            FinestraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FinestraLayout.setVerticalGroup(
            FinestraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Compilatore JavaScript");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icona_client.png")));
        setLocation(new java.awt.Point(500, 500));
        setResizable(false);

        jPanel.setBackground(new java.awt.Color(255, 255, 255));

        Start_Btn.setText("Avvia Client");
        Start_Btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start_BtnMouseClicked(evt);
            }
        });

        Titolo_Lbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Titolo_Lbl.setText("Compilatore JavaScript");
        Titolo_Lbl.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        Porta_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Porta_Lbl.setText("Porta");

        InfoPorta_Lbl.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        InfoPorta_Lbl.setForeground(new java.awt.Color(204, 0, 0));
        InfoPorta_Lbl.setText("Inserire una porta non bloccata dal Firewall");

        Chiave_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Chiave_Lbl.setText("Chiave di crittografia (facoltativo)");

        Indirizzo_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Indirizzo_Lbl.setText("Indirizzo");

        Indirizzo_Tbx.setToolTipText("Inserire un indirizzo IPv4 o \"localhost\" se eseguito in locale.");

        Porta_Tbx.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        Porta_Tbx.setToolTipText("Es: 6700");

        Chiave_Tbx.setToolTipText("Crittografia eseguita con XOR");

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(InfoPorta_Lbl)
                            .addGroup(jPanelLayout.createSequentialGroup()
                                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Indirizzo_Lbl)
                                    .addComponent(Porta_Lbl))
                                .addGap(18, 18, 18)
                                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Indirizzo_Tbx)
                                    .addGroup(jPanelLayout.createSequentialGroup()
                                        .addComponent(Porta_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Chiave_Lbl))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(Titolo_Lbl))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(Chiave_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Start_Btn)
                .addGap(61, 61, 61))
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Titolo_Lbl)
                .addGap(23, 23, 23)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Indirizzo_Lbl)
                    .addComponent(Indirizzo_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Porta_Lbl)
                    .addComponent(Porta_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addComponent(InfoPorta_Lbl)
                .addGap(18, 18, 18)
                .addComponent(Chiave_Lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Chiave_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(Start_Btn)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Start_BtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start_BtnMouseClicked
        
        /*
            Effettuando l'assegnazione in LowerCase, sarà successivamente
            possibile la verifica del "localhost" in modo case-insensitive.
        */
        String indirizzo = Indirizzo_Tbx.getText().toLowerCase();
        
        /*
          Pattern per la verifica di un indirizzo IPv4 (4 ottetti) con dotted notation.
          Fonte : https://stackoverflow.com/questions/5667371/validate-ipv4-address-in-java
         */
        String PATTERN = "^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$";
        
        // 1 -- Viene verificato che sia l'indirizzo che la porta siano stati inseriti.
        if(Indirizzo_Tbx.getText().isEmpty() || Porta_Tbx.getText().isEmpty())
            //In caso di errata immissione, l'utente viene avvertito con un messaggio di dialogo di tipo "ERROR_MESSAGE".
            jOptionPane.showMessageDialog(null, "L'inserimento di una porta ed un indirizzo validi sono obbligatori", "Errore", jOptionPane.ERROR_MESSAGE);
        else    
            /*
                2 -- Viene verificato che l'indirizzo sia valido.
                Ovvero che sia un IPv4 valido o che sia un localhost(case-insensitive)
            */
            if(!indirizzo.matches(PATTERN) && !indirizzo.equals("localhost"))
               jOptionPane.showMessageDialog(null, "L'Indirizzo inserito non è valido.\nSpecificare un indirizzo"
                       + "IPv4 da 32 utilizzando la dotted notation\noppure inserire \"localhost\" se "
                       + "eseguito in locale.", "Errore", jOptionPane.ERROR_MESSAGE);
            else{
                
                int porta = Integer.parseInt(Porta_Tbx.getText());
            
                /*
                    3 -- Viene verificato che la porta non superi il valore massimo di 65535
                    e che non vada in conflitto con una "Well Know" ovvero una porta riservata.
                
                    NB: Non è necessario verificare che il valore sia 
                    esclusivamente numerico poiché il text area è formattato per soli interi.
                */
                if(porta < 1024 || porta > 65535)
                jOptionPane.showMessageDialog(null, "Devi inserire una porta con valore compreso tra 1024-65535.\n"
                        + "Ricorda che le porte riservate dette \"Well Known\" sono 0-1023.", "Errore", jOptionPane.ERROR_MESSAGE);
                else{
                    //Viene aperta una nuova finestra e chiusa quella corrente.
                    this.setVisible(false);
                    Finestra.setVisible(true);
                    
                    //Vengono salvati porta ed indirizzo nelle variabili globali
                    setPorta(porta);
                    setIndirizzo(indirizzo);
                    
                    //Viene salvata la chiave nella variabile globale
                    //Dopo essere stata trasformata in Stringa ( da char[])
                    String key = new String(Chiave_Tbx.getPassword());
                    setKey(key);
                    
                    //In caso di chiave immessa, viene segnalata
                    //la comunicazione criptata attraverso un'icona speciale.
                    if(key.isEmpty())
                        chiave_ico.setVisible(false);
                    else
                        chiave_ico.setVisible(true);
                    
                    //Viene creato un oggetto caret (il puntatore della barra di scorrimento
                    //e viene indicato che dovrà scendere quando viene stampato un nuovo testo nella TextArea del Log.
                    DefaultCaret caret = (DefaultCaret)Log_TA.getCaret();
                    caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
                    
                    //Vengono indicati l'indirizzo e la porta su cui si comunica in una label nella schermata.
                    info_Lbl.setText(indirizzo + ": " + porta);
                    
                    //Stampa effettuata nel Log(TextArea).
                    Log_TA.setText(Log_TA.getText()+"\n\nIn attesa di esecuzione...");
                }
            }
    }//GEN-LAST:event_Start_BtnMouseClicked

    private void FinestraWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_FinestraWindowClosed
        /*
            Quando si chiude la nuova finestra, viene ripristinata la seconda
            
            NB: Ciò non arresta l'esecuzione del programma poiché la seconda 
            finestra ha la proprietà "defaultCloseOperation" settata a DISPOSE.
        */
        this.setVisible(true);
    }//GEN-LAST:event_FinestraWindowClosed

    private void Esegui_BtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Esegui_BtnMouseClicked
        
       /*  
                    !IMPORTANTE!
        Viene creato un nuovo thread per l'esecuzione del codice del client.
        Ciò permette alla GUI di essere attiva durante l'esecuzione.
       */
       new Thread(new Runnable()
       {

         public void run(){
             
                String Codice_JS = Inserimento_TA.getText();
                if(Codice_JS.isEmpty()){
                    //Prima di proseguire, viene verificata l'immissione del codice da eseguire nella TextArea.
                    
                    jOptionPane.showMessageDialog(null, "Devi inserire un codice JavaScript per continuare!", "Errore", jOptionPane.ERROR_MESSAGE);
                }
                else{
                        Log_TA.setText(Log_TA.getText()+"\nConnessione in corso...");
                        
                        Socket socket;
                   
                        BufferedReader bufferedR;
                        
                        PrintWriter     Print_W;
                        
                        String key = getKey();

                        try
                        {
                            socket = new Socket(getIndirizzo(), getPorta());
                            
                            //Connessione aperta
                            Log_TA.setText(Log_TA.getText()+"\nCONNESSO!");
                            
                            //Viene istanziato il flusso di I/O.
                            Print_W = new PrintWriter( socket.getOutputStream());
                            bufferedR = new BufferedReader( new InputStreamReader( socket.getInputStream()));
                            
                            //Creazione dell'oggetto JSON con il codice JS associato alla chiave "codice_sorgente".
                            JSONObject jsonObject = crea_JSON("codice_sorgente", Codice_JS);
                            
                            //Viene trasformato l'oggetto JSON in stringa per permettere l'eventuale crittografia.
                            String jsonString = jsonObject.toString();
                                                
                            if(!key.isEmpty()){
                                /*
                                    Viene richiamato il metodo per la (de)crittografia solo se è stata inserita una chiave.
                                
                                    NB: La crittografia XOR permette di utilizzare un solo metodo per entrambe le
                                    operazioni(sia cifratura che decifratura).
                                */
                                jsonString = cifra_decifra_XOR(key, jsonString);

                                Log_TA.setText(Log_TA.getText()+"\nStringa criptata.");
                            }
                            
                            //Viene mandato il codice da eseguire.
                            Print_W.println(jsonString);
                            
                            /*
                                Viene ripulito il flusso di output.
                                Ciò serve per sbloccare il Server dalla lettura dello stream.
                            
                                NB: Utilizzare semplicemente il metodo .close() in questo caso non
                                è corretto, infatti verrebbe lanciata un'eccezione.
                            */
                            Print_W.flush();
                            
                            Log_TA.setText(Log_TA.getText()+"\nCodice inviato.");            
                            
                            //Viene effettuata la lettura dello stream di input.
                            jsonString = bufferedR.readLine();
                            
                            Log_TA.setText(Log_TA.getText()+"\nCodice ricevuto.");
                            
                            if(!key.isEmpty()){
                                //Decrittografia.
                                jsonString = cifra_decifra_XOR(key, jsonString);

                                Log_TA.setText(Log_TA.getText()+"\nStringa decriptata.");
                            }

                            //Viene ricavato il valore associato alla chiave "codice_eseguito", e stampata nella Text Area del risultato.
                            Risultato_TA.setText(JSON_ToString("codice_eseguito", jsonString));

                            // Chiude flusso I/O e connessione.
                            bufferedR.close() ;
                            Print_W.close();
                            socket.close();

                            Log_TA.setText(Log_TA.getText()+"\nConnessione chiusa senza errori.");
                            
                        }
                        catch ( Exception e ) {
                            
                            //In caso di eccezione lanciata, viene visualizzato il messaggio di errore sulla GUI
                            //sia attraverso il messaggio di dialogo che il Log
                            jOptionPane.showMessageDialog(null, "Errore: " + e, "Qualcosa è andato storto...", jOptionPane.ERROR_MESSAGE);
                            
                            Log_TA.setText(Log_TA.getText()+"\nConnessione chiusa: "+e);
                   
                    }
                }
           }
       }).start();
    }//GEN-LAST:event_Esegui_BtnMouseClicked

    private void Clear_BtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Clear_BtnMouseClicked
        //Pulsante per la pulizia del Log.
        Log_TA.setText("");
    }//GEN-LAST:event_Clear_BtnMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
          Gli oggetti Swing non sono thread-safe.
          SwingUtilities.invokeLater() permette alle istruzioni di
          essere eseguite su un thread diverso in un momento diverso.
        
          Fonte: https://stackoverflow.com/questions/3551542/swingutilities-invokelater-why-is-it-needed
        */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Client().setVisible(true);
            }
            
        });
    }
    
    
    public int getPorta(){
        return porta;
    }
    
    public void setPorta(int porta){
       this.porta = porta;
    }
    
    public String getIndirizzo(){
        return indirizzo;
    }
    
    public void setIndirizzo(String indirizzo){
        this.indirizzo = indirizzo;
    }
    
    public String getKey(){
        return key;
    }
    
    public void setKey(String key){
        this.key = key;
    }
    
    public JSONObject crea_JSON(String key, String codice){
        JSONObject jsonObject = new JSONObject() ;
        jsonObject.put(key, codice) ;
        
        return jsonObject;
    }
    
    public String JSON_ToString(String key, String codice){
        
        String codice_eseguito = "";
        //Interprete per trasformare la stringa JSON in array associativo.
        JSONParser jsonParser = new JSONParser();
        
        try{
            //Traduzione eseguita in linea (codice ridotto).  
            JSONObject jsonObject = ( JSONObject )jsonParser.parse(codice);
            
            codice_eseguito = jsonObject.get(key).toString();
        }
        catch(Exception e){
            jOptionPane.showMessageDialog(null, "Errore: " + e, "Qualcosa è andato storto...", jOptionPane.ERROR_MESSAGE);
        }
       
        return codice_eseguito;
    }
    
    public String cifra_decifra_XOR(String key, String stringa){
        
        String ris = "";
        int x = 0;
        
        for(int i=0; i<stringa.length(); i++){
            /*
                Viene aggiunto 32 all'ASCII di ciascun char per evitare di trasformare il testo 
                in caratteri di controllo non stampabili. Es: enter.
                Infatti dal carattere 32 in poi (32 incluso), tutti gli ASCII sono stampabili.
            */
            ris += (char)((int)stringa.charAt(i) ^ (int)key.charAt(x) + 32);
            
            x++;
            if(x == key.length())
                x = 0;
        }
        
        return ris;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Chiave_Lbl;
    private javax.swing.JPasswordField Chiave_Tbx;
    private javax.swing.JButton Clear_Btn;
    private javax.swing.JButton Esegui_Btn;
    private javax.swing.JFrame Finestra;
    private javax.swing.JLabel Indirizzo_Lbl;
    private javax.swing.JTextField Indirizzo_Tbx;
    private javax.swing.JLabel InfoPorta_Lbl;
    private javax.swing.JLabel Inserimento_Lbl;
    private javax.swing.JTextArea Inserimento_TA;
    private javax.swing.JLabel Log_Lbl;
    private javax.swing.JTextArea Log_TA;
    private javax.swing.JLabel Porta_Lbl;
    private javax.swing.JFormattedTextField Porta_Tbx;
    private javax.swing.JLabel Risultato_Lbl;
    private javax.swing.JTextArea Risultato_TA;
    private javax.swing.JButton Start_Btn;
    private javax.swing.JLabel Titolo2_Lbl;
    private javax.swing.JLabel Titolo_Lbl;
    private javax.swing.JLabel chiave_ico;
    private javax.swing.JLabel info_Lbl;
    private javax.swing.JOptionPane jOptionPane;
    private javax.swing.JPanel jPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
