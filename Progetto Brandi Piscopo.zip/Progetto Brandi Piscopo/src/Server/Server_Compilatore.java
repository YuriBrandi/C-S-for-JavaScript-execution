/*
    © Brandi Yuri & Piscopo Roberto.
*/
package Server;

import java.net.* ;
import java.io.* ;

// JAR Simple Json: http://www.java2s.com/Code/Jar/j/Downloadjsonsimple111jar.htm
import org.json.simple.* ;
import org.json.simple.parser.* ;

//Classe necessaria per l'implementazione del JFrame.setIconImage(...).
import java.awt.Toolkit;

//Classi per l'esecuzione del JavaScript
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

/*
    Classe necessaria per la modifica del "caret", ovvero del
    cursore della barra di scorrimento della TextArea.
    In questo caso serve per abilitare lo scroll automatico
    quando viene stampato del testo nuovo nel Log.
*/
import javax.swing.text.DefaultCaret;

public class Server_Compilatore extends javax.swing.JFrame {
    
    /*
        L'oggetto ServerSocket viene gestito attraverso opportuni metodi get/set.
    
        È stato istanziato per permettere la chiusura del ServerSocket in 
        un metodo (e thread) diverso, quando viene richiesto dall'utente o in caso di errore.
    
        In questo modo si può sempre "riciclare" la stessa porta di connessione.
    */
    private ServerSocket Server_Sock ;
    
    public Server_Compilatore() {
        initComponents();
        
         
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane = new javax.swing.JOptionPane();
        jPanel = new javax.swing.JPanel();
        Start_Btn = new javax.swing.JButton();
        Titolo_Lbl = new javax.swing.JLabel();
        Porta_Lbl = new javax.swing.JLabel();
        Porta_Tbx = new javax.swing.JTextField();
        InfoPorta_Lbl = new javax.swing.JLabel();
        Chiave_Lbl = new javax.swing.JLabel();
        Chiave_Tbx = new javax.swing.JPasswordField();
        Stop_Btn = new javax.swing.JButton();
        Log_Lbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Log_TA = new javax.swing.JTextArea();
        Clear_Btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Server compilatore JS");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icona_server.png")));
        setLocation(new java.awt.Point(500, 500));
        setPreferredSize(new java.awt.Dimension(220, 383));
        setResizable(false);
        setSize(new java.awt.Dimension(215, 383));

        jPanel.setBackground(new java.awt.Color(255, 255, 255));

        Start_Btn.setText("Avvia Server");
        Start_Btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start_BtnMouseClicked(evt);
            }
        });

        Titolo_Lbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Titolo_Lbl.setText("Server compilatore JS");
        Titolo_Lbl.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        Porta_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Porta_Lbl.setText("Porta");

        Porta_Tbx.setToolTipText("Es: 6700");

        InfoPorta_Lbl.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        InfoPorta_Lbl.setForeground(new java.awt.Color(204, 0, 0));
        InfoPorta_Lbl.setText("Inserire una porta non bloccata dal Firewall");

        Chiave_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Chiave_Lbl.setText("Chiave di crittografia (facoltativo)");

        Chiave_Tbx.setToolTipText("Crittografia eseguita con XOR");

        Stop_Btn.setText("Arresta Server");
        Stop_Btn.setEnabled(false);
        Stop_Btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop_BtnMouseClicked(evt);
            }
        });

        Log_Lbl.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Log_Lbl.setText("Log");

        Log_TA.setEditable(false);
        Log_TA.setBackground(new java.awt.Color(0, 0, 0));
        Log_TA.setColumns(20);
        Log_TA.setForeground(new java.awt.Color(255, 255, 255));
        Log_TA.setRows(5);
        Log_TA.setText("~~~ © Brandi & Piscopo ~~~");
        Log_TA.setSelectionColor(new java.awt.Color(255, 0, 204));
        jScrollPane1.setViewportView(Log_TA);

        Clear_Btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Server/baseline_delete_black_18dp.png"))); // NOI18N
        Clear_Btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Clear_BtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(Porta_Lbl))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(InfoPorta_Lbl))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(Titolo_Lbl))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Chiave_Lbl)
                            .addGroup(jPanelLayout.createSequentialGroup()
                                .addComponent(Start_Btn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Stop_Btn))))
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(Porta_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelLayout.createSequentialGroup()
                        .addComponent(Log_Lbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Clear_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(Chiave_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Titolo_Lbl)
                .addGap(18, 18, 18)
                .addComponent(Porta_Lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Porta_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(InfoPorta_Lbl)
                .addGap(18, 18, 18)
                .addComponent(Chiave_Lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Chiave_Tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Start_Btn)
                    .addComponent(Stop_Btn))
                .addGap(18, 18, 18)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Clear_Btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Log_Lbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Start_BtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start_BtnMouseClicked
        

        // 1 -- Viene verificata l'immissione della porta. 
        if(Porta_Tbx.getText().isEmpty())
            //In caso di errata immissione, l'utente viene avvertito con un messaggio di dialogo di tipo "ERROR_MESSAGE".
              jOptionPane.showMessageDialog(null, "Devi prima inserire una porta di connessione!", "Errore", jOptionPane.ERROR_MESSAGE);
         else{
            
             int porta = Integer.parseInt(Porta_Tbx.getText());
             /*
                    2 -- Viene verificato che la porta non superi il valore massimo di 65535
                    e che non vada in conflitto con una "Well Know" ovvero una porta riservata.
                
                    NB: Non è necessario verificare che il valore sia 
                    esclusivamente numerico poiché il text area è formattato per soli interi.
             */
             if(porta < 1024 || porta > 65535)
                jOptionPane.showMessageDialog(null, "Devi inserire una porta con valore compreso tra 1024-65535.\n"
                        + "Ricorda che le porte riservate dette \"Well Known\" sono 0-1023.", "Errore", jOptionPane.ERROR_MESSAGE);
             else{
                 
                    //Questo metodo disabilita tutti i campi di immissione e il pulsante start
                    //riattivando invece quello per l'arresto.
                    setMode(true);
                    
                    //Viene creato un oggetto caret (il puntatore della barra di scorrimento
                    //e viene indicato che dovrà scendere quando viene stampato un nuovo testo nella TextArea del Log.
                    DefaultCaret caret = (DefaultCaret)Log_TA.getCaret();
                    caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
                    
                    //Viene trasformata la password in Stringa ( da char[])
                    String key = new String(Chiave_Tbx.getPassword());
                    
                /*
                    Viene creato un nuovo thread per l'esecuzione del server.
                    Ciò permette alla GUI di essere attiva durante l'esecuzione
                    del ciclo "while" del server multiclient che contiene metodi bloccanti.
                */
                new Thread(new Runnable() {
                public void run() {
                     Server_exe(porta, key);
                }
                }).start();
                 
             }
         }
    }//GEN-LAST:event_Start_BtnMouseClicked

    private void Stop_BtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop_BtnMouseClicked
       //Arresto volontario del server.
       Stop_Server();
    }//GEN-LAST:event_Stop_BtnMouseClicked

    private void Clear_BtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Clear_BtnMouseClicked
        //Pulsante per la pulizia del Log.
        Log_TA.setText("");
    }//GEN-LAST:event_Clear_BtnMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Server_Compilatore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Server_Compilatore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Server_Compilatore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Server_Compilatore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /*
          Gli oggetti Swing non sono thread-safe.
          SwingUtilities.invokeLater() permette alle istruzioni di
          essere eseguite su un thread diverso in un momento diverso.
        
          Fonte: https://stackoverflow.com/questions/3551542/swingutilities-invokelater-why-is-it-needed
        */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Server_Compilatore().setVisible(true);
            }
        });
    }
    
    public void Server_exe(int porta, String key){
               
        ServerSocket    Server_Sock ;
        
        Socket          socket ;
        
        BufferedReader bufferedR;
        
        PrintWriter     Print_W ;
        
        try
        {
            Server_Sock = new ServerSocket(porta) ;
            
            /*
              Viene salvato il ServerSocket per essere chiuso in un altro metodo
              e un altro thread dopo che il .accept() bloccante occupi inutilmente la porta.
            */
            setServerSocket(Server_Sock);
             
            Log_TA.setText(Log_TA.getText()+"\n\nAvvio del server in corso...");

            //Il ciclo while rende il server multiclient.
            while(true)
            {
                Log_TA.setText(Log_TA.getText()+"\nIn attesa di connessione...");
                
                
                socket = Server_Sock.accept() ;
                //Connessione stabilita.
                
                Log_TA.setText(Log_TA.getText()+"\nConnessione stabilita.");
                
                //Viene istanziato il flusso di I/O.
                bufferedR = new BufferedReader( new InputStreamReader( socket.getInputStream()));
                Print_W = new PrintWriter(socket.getOutputStream()); 
                
                //Viene effettuata la lettura dello stream di input.
                String jsonString = bufferedR.readLine();
                
                Log_TA.setText(Log_TA.getText()+"\nLettura eseguita.");
                
                if(!key.isEmpty()){
                    /*
                        Viene richiamato il metodo per la (de)crittografia solo se è stata inserita una chiave.
                                
                        NB: La crittografia XOR permette di utilizzare un solo metodo per entrambe le
                        operazioni(sia cifratura che decifratura).
                    */
                    jsonString = cifra_decifra_XOR(key, jsonString);
                    
                    Log_TA.setText(Log_TA.getText()+"\nStringa decriptata.");
                }
                //Viene ricavato il valore associato alla chiave "codice_sorgente"
                String codice_eseguito = esegui_JS(JSON_ToString("codice_sorgente", jsonString));
                
                Log_TA.setText(Log_TA.getText()+"\nCodice JavaScript eseguito.");
                	   
                //Creazione dell'oggetto JSON con il codice JS associato alla chiave "codice_eseguito".
                JSONObject jsonObject = crea_JSON("codice_eseguito", codice_eseguito);
                
                //Viene trasformato l'oggetto JSON in stringa per permettere l'eventuale crittografia.
                jsonString = jsonObject.toString();
                        
                if(!key.isEmpty()){
                    //Crittografia.
                    jsonString = cifra_decifra_XOR(key, jsonString);
                    
                    Log_TA.setText(Log_TA.getText()+"\nStringa criptata.");
                }

                // Invio del codice eseguito al Client.
                Print_W.println(jsonString);
                
                /*
                    Viene ripulito il flusso di output.
                    Ciò serve per sbloccare il Client dalla lettura dello stream.
                            
                    NB: Utilizzare semplicemente il metodo .close() in questo caso non
                     è corretto, infatti verrebbe lanciata un'eccezione.
                */
                Print_W.flush();
                
                Log_TA.setText(Log_TA.getText()+"\nStampa eseguita.");
                
                // Chiude flusso I/O e connessione.
                Print_W.close() ;
                bufferedR.close();
                socket.close() ;
                
                Log_TA.setText(Log_TA.getText()+"\nConnessione chiusa senza errori.");
            }
        }
        catch( Exception e ) {
            /*
                In caso di arresto volontario si evita di stampare 
                l'eccezione poiché non si tratta di un errore vero è proprio,
                ma di una normale conseguenza.
            
                Viene stampato invece un messaggio di avvenuto arresto.
            */
            if(e.toString().equals("java.net.SocketException: socket closed")){
                Log_TA.setText(Log_TA.getText()+"\nServer arrestato.");
            }
            else{
                /*
                    In caso di eccezione lanciata, viene stampato l'errore nel Log.
                    
                    NB: al contrario del Client, qui si evita di usare messaggi di dialogo
                    per gli errori poiché bloccano la normale esecuzione del server.
                */
                Log_TA.setText(Log_TA.getText()+"\nConnessione chiusa: "+e);
                
                //In caso di errore, viene arrestato il server liberando la porta occupata.
                Stop_Server();
            }
        }
        
        
    }
    
    public JSONObject crea_JSON(String key, String codice){
        JSONObject jsonObject = new JSONObject() ;
        jsonObject.put(key, codice) ;
        
        return jsonObject;
    }
    
    public String JSON_ToString(String key, String codice){
        
        String codice_eseguito = "";
        //Interprete per trasformare la stringa JSON in array associativo.
        JSONParser jsonParser = new JSONParser();
        
        try{   
            //Traduzione eseguita in linea (codice ridotto).  
            JSONObject jsonObject = ( JSONObject )jsonParser.parse(codice);
            
            codice_eseguito = jsonObject.get(key).toString();
        }
        catch(Exception e){
            Log_TA.setText(Log_TA.getText()+"\nErrore is JSONParser: "+e);
        }
       
        return codice_eseguito;
    }
    
    public String esegui_JS(String codice_sorgente){
        
        /*
            Lo ScriptEngineManager implementa meccanismi di istanziazione per lo ScriptEngine, che include metodi 
            per l'esecuzione di script.
        
            Fonte: https://docs.oracle.com/javase/7/docs/api/javax/script/ScriptEngineManager.html
        */
        ScriptEngineManager manager = new ScriptEngineManager();
        
        //Crea uno ScriptEngine per JavaScript (js) 
        ScriptEngine engine = manager.getEngineByName( "js" ) ;
				
	Object result = null ;
				
	try{

            //Il metodo eval() permette di eseguire gli script.
            result = engine.eval(codice_sorgente) ;
	}
	catch ( Exception e ){
            Log_TA.setText(Log_TA.getText()+"\nErrore in esegui_JS: "+e);
            //In caso di errore, viene restituito l'errore così com'è per
            //essere stampato e letto dal client come esito dell'operazione.
            return "Errore: "+e;
        }
        
	return result.toString() ;
    }
    
    public void setMode(boolean acceso){
        if(acceso){
                 /*
                    Quando il server è acceso, viene disabilitato il pulsante Start
                    e le TextBox di immissione. Viene invece riabilitato il pulsante Stop.    
                */
                 Stop_Btn.setEnabled(true); 
                 Start_Btn.setEnabled(false);
                 Porta_Tbx.setEnabled(false);
                 Chiave_Tbx.setEnabled(false);
                 
                
        }
        else{
                /*
                    Quando il server è spento, viene disabilitato il pulsante Stop.
                    Vengono invece riabilitati il pulsante Stop e le TextBox di immissione.
                */
                Stop_Btn.setEnabled(false);

                Start_Btn.setEnabled(true);
                Porta_Tbx.setEnabled(true);
                Chiave_Tbx.setEnabled(true);
        }
    }
    
    public void setServerSocket(ServerSocket Server_Sock){
        this.Server_Sock = Server_Sock;
        
    }
    
    public ServerSocket getServerSocket(){
        return Server_Sock;
        
    }
    
    public void Stop_Server(){
        
        /*
            Questo metodo viene richiamato: 
                1. In caso di eccezione lanciata.
                2. In caso di arresto volontario mediante pulsante Stop.
        
            Viene aggiornata la modalità della GUI, viene recuperato l'oggetto
            del ServerSocket chiudendo la connessione e liberando la porta occupata.
        */
        setMode(false);

            try{
                ServerSocket Server_s = getServerSocket();

                Server_s.close();
            }
            catch(Exception e){}
    }
    
    public String cifra_decifra_XOR(String key, String stringa){
        
        String ris = "";
        int x = 0;
        
        for(int i=0; i<stringa.length(); i++){
            /*
                Viene aggiunto 32 all'ASCII di ciascun char per evitare di trasformare il testo 
                in caratteri di controllo non stampabili. Es: enter.
                Infatti dal carattere 32 in poi (32 incluso), tutti gli ASCII sono stampabili.
            */
            ris += (char)((int)stringa.charAt(i) ^ (int)key.charAt(x) + 32);
            
            x++;
            if(x == key.length())
                x = 0;
        }
        
        return ris;
    }
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Chiave_Lbl;
    private javax.swing.JPasswordField Chiave_Tbx;
    private javax.swing.JButton Clear_Btn;
    private javax.swing.JLabel InfoPorta_Lbl;
    private javax.swing.JLabel Log_Lbl;
    private javax.swing.JTextArea Log_TA;
    private javax.swing.JLabel Porta_Lbl;
    private javax.swing.JTextField Porta_Tbx;
    private javax.swing.JButton Start_Btn;
    private javax.swing.JButton Stop_Btn;
    private javax.swing.JLabel Titolo_Lbl;
    private javax.swing.JOptionPane jOptionPane;
    private javax.swing.JPanel jPanel;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
